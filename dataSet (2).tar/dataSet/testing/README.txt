This data set contains 100 images collected with Google Images for each of the eleven color names: black, blue, brown, grey, green, orange, pink, purple, red, white, yellow. For the query the term 'color' has been added. Hence the red images are queried with 'red+color'. The raw results are given, including images which do not contain the query color.

The set has been used in:
"Learning Color Names from Real-World Images"
Joost van de Weijer, Cordelia Schmid, Jakob Verbeek
CVPR 2007, Minneapolis, USA.